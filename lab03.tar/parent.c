#include<stdio.h>
#include<sys/types.h>
#include<sys/time.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
void sortstr(char** a,int str)
{
	int o1=0,o2=0,k=0;
	char *temp;
	for(o1=0;o1<str;o1++)
		for(o2=o1+1;o2<str;o2++)
			for(k=0;k<256;k++)
			{
				if(a[o1][k]==a[o2][k]) continue;
				else if(a[o1][k]>a[o2][k])
				{
					temp=*(a+o1);
					*(a+o1)=*(a+o2);
					*(a+o2)=temp;
					break;
				}
				else break;
			}
}
extern char** environ;
char* find(char* environ[],int con)
{
	for(int i=0;i<con;i++)
	{
		if(strcmp(environ[i],"CHILD_PATH=/home/kali/progi/lab02/child")==0) 
			return "/home/kali/progi/lab02/child";
	}
	return NULL;
}
int main(int argc, char* argv[],char* env[])
{
	char** str;
	int con;
	for(con=0;;con++) if(env[con]==NULL) break;
	str=(char**)calloc(con,sizeof(char*));
	for(int i=0;i<con;i++)
	{
		str[i]=(char*)calloc(strlen(env[i]),sizeof(char));
		for(int j=0;j<strlen(env[i]);j++) str[i][j]=env[i][j];
	}
	sortstr(str,con);
	for(int i=0;i<con;i++) printf("%s\n",str[i]);
	printf("\n\n");
	pid_t pid;
	char* so[]={"hello","world","   "};
	for(int T=0;T<99;T++)
	{
		char a;
		a=getchar();
		if(a=='+')
		{
			printf("**********PROCESS CHILD № %d *********** \n",T/2);
			pid=fork();
			if(!pid)
			{
				int ret;
				ret=execve(getenv("CHILD_PATH"),so,env);
			}
		}
		else if(a=='*')
		{
			printf("**********PROCESS CHILD № %d *********** \n",T/2);
			pid=fork();
			if(!pid)
			{
				int ret;
				ret=execve(find(env,con),so,env);
			}

		}
		else if(a=='&')
		{
			printf("**********PROCESS CHILD № %d *********** \n",T/2);
			pid=fork();
			if(!pid)
			{
				int ret;
				ret=execve(find(environ,con),so,env);
			}
			break;
		}
		
	}
	for(int i=0;i<con;i++) free(str[i]);
	free(str);
	return 0;
}