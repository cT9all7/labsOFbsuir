#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
int main(int argc, char* argv[],char* env[])
{
	printf("parent %d \n", getppid());
	printf("child %d \n", getpid());
	printf("\n\n");
	for(int i=0;env[i];i++)
		printf("%s\n",env[i]);
	for(int i=0;i<argc;i++)
		printf("%s\n",argv[i]);
	exit (EXIT_SUCCESS);
	return 0;
}