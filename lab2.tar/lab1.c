#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
int readlink(char *a,char* b,int c);
int fs(char* fdir);
int ds(char* fdir);
int dl( char* fdir);
int ls(char* fdir);
void df(DIR* dir, char* fdir);
int fls(char* fdir);
int dls(char* fdir);
void dfs(char* fdir);
void sortstr(char** a,int str, int sto);
void sorts(char *a, int str);
void jony(DIR* dir, char* fdir);
void jony2(DIR* dir, char* fdir);
int jony3(DIR* dir, char* fdir);
int jony4(DIR* dir, char* fdir);
void jony5(char* fdir);

int main(int argc, char *argv[])
{
	DIR* dir;
	dir=NULL;
	int i=2;
	if(argc>=3){
		while(i!=argc)
		{
			
			sorts(*(argv+i),strlen(*(argv+i)));
			if (strcmp(*(argv+i),"-dfls")==0)
			{
				printf("############# -dfls ###########\n");
				jony5(*(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-dfs")==0)
			{
				printf("############# -dfs ###########\n");
				dfs(*(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-dls")==0)
			{
				printf("############# -dls ###########\n");
				dls(*(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-dfl")==0)
			{
				printf("############# -dfl ###########\n");
				jony(dir,*(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-fls")==0)
			{
				printf("############# -fls ###########\n");
				fls(*(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-df")==0)
			{
				printf("############# -df ###########\n");
				df(dir,*(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-ls")==0)
			{
				printf("############# -ls ###########\n");
				ls(*(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-fl")==0)
			{
				printf("############# -fl ###########\n");
				jony4(dir, *(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-dl")==0)
			{
				printf("############# -dl ###########\n");
				dl(*(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-ds")==0)
			{
				printf("############# -ds ###########\n");
				ds(*(argv+1));
				break;
			}
			if(strcmp(*(argv+i),"-fs")==0)
			{
				printf("############# -fs ###########\n");
				fs(*(argv+1));
				break;
			}
			if( *(*(argv+i)+1)=='l' ){
				printf("\n&&&&&&& symlink &&&&&&\n");
				jony2(dir,*(argv+1));
				break;
			}
			if(*(*(argv+i)+1)=='d'){
				printf("\n&&&&&&& DIRECTORY &&&&&&\n");
				jony3(dir,*(argv+1));
				break;
			}
			if(*(*(argv+i)+1)=='f'){
				printf("\n&&&&&&& FILES &&&&&&\n");	
				jony4(dir,*(argv+1));
				break;
			}
			if(*(*(argv+i)+1)=='s'){
				printf("\n&&&&&&& SORT &&&&&&\n");
				jony5(*(argv+1));
				break;
			}
			
			i++;
		}
	}
	else if(argc<3) jony(dir,*(argv+1));
	return 0;
}
void sorts(char* a, int str)
{
	char b;
	for(int i=0;i<str;i++)
		for(int j=i+1;j<str;j++)
		{
			if(a[i]>a[j])
			{
				b=a[i];
				a[i]=a[j];
				a[j]=b;
			}
		}
} 
void sortstr(char** a,int str, int sto)
{
	int o1=0,o2=0,k=0;
	char *temp;
	for(o1=0;o1<str;o1++)
		for(o2=o1+1;o2<str;o2++)
			for(k=0;k<sto;k++)
			{
				if(a[o1][k]==a[o2][k]) continue;
				else if(a[o1][k]>a[o2][k])
				{
					temp=*(a+o1);
					*(a+o1)=*(a+o2);
					*(a+o2)=temp;
					break;
				}
				else break;
			}
}
void jony (DIR* dir, char* fdir)
{
	struct dirent* inf;
	char* temp;
	int num;
	if((dir=opendir(fdir))==NULL) return;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		temp=(char*)calloc(num+2,sizeof(char));
		strncat(temp,fdir,strlen(fdir));
		strncat(temp,"/",2);
		strncat(temp,inf->d_name,strlen(inf->d_name));
		printf("%s\n",temp);
		jony(dir, temp);
		free(temp);
	}
	closedir(dir);
	return;
}
void jony2(DIR* dir, char* fdir)
{
	struct dirent* inf;
	char a[256];
	char* temp;
	int num, num1;
	if((dir=opendir(fdir))==NULL) return;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		temp=(char*)calloc(num+2,sizeof(char));
		strncat(temp,fdir,strlen(fdir));
		strncat(temp,"/",2);
		strncat(temp,inf->d_name,strlen(inf->d_name));
		num1=readlink(temp,a,256);
		if(num1!=-1)
			printf("%s\n",temp);
		else
			jony2(dir, temp);
		free(temp);
	}
	closedir(dir);
	return;
}
int jony3(DIR* dir, char* fdir)
{
	struct dirent* inf;
	char* temp;
	int num;
	if((dir=opendir(fdir))==NULL) return 1;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		temp=(char*)calloc(num+2,sizeof(char));
		strncat(temp,fdir,strlen(fdir));
		strncat(temp,"/",2);
		strncat(temp,inf->d_name,strlen(inf->d_name));
		if(jony3(dir,temp)==1) continue;
		else printf("%s\n",temp);
		free(temp);
	}
	closedir(dir);
	return 0;
}
int jony4(DIR* dir, char* fdir)
{
	struct dirent* inf;
	char* temp;
	int num;
	if((dir=opendir(fdir))==NULL) return 1;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		temp=(char*)calloc(num+2,sizeof(char));
		strncat(temp,fdir,strlen(fdir));
		strncat(temp,"/",2);
		strncat(temp,inf->d_name,strlen(inf->d_name));
		if(jony4(dir,temp)==0) continue;
		else printf("%s\n",temp);
		free(temp);
	}
	closedir(dir);
	return 0;
}
void jony5(char* fdir)
{
	DIR* dir;
	struct dirent* inf;
	char** temp;
	int num;
	int num1=0;

	if((dir=opendir(fdir))==NULL) return;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.') continue;
		num1++;
	}
	temp=(char**)calloc(num1,sizeof(char*));
	rewinddir(dir);
	int i=0;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		*(temp+i)=(char*)calloc(num+2,sizeof(char));
		strncat(*(temp+i),fdir,strlen(fdir));
		strncat(*(temp+i),"/",2);
		strncat(*(temp+i),inf->d_name,strlen(inf->d_name));
		i++;
	}
	sortstr(temp,num1,256);
	for(i=0;i<num1;i++)
	{
		jony5(*(temp+i));
		 printf("%s\n",*(temp+i));
	}
	for(i=0;i<num1;i++) free(*(temp+i));
	free(temp);
	closedir(dir);
}
void dfs(char* fdir)
{
	DIR* dir;
	struct dirent* inf;
	char** temp;
	int num;
	int num1=0;
	char A[256];

	if((dir=opendir(fdir))==NULL) return;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.') continue;
		num1++;
	}
	temp=(char**)calloc(num1,sizeof(char*));
	rewinddir(dir);
	int i=0;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		*(temp+i)=(char*)calloc(num+2,sizeof(char));
		strncat(*(temp+i),fdir,strlen(fdir));
		strncat(*(temp+i),"/",2);
		strncat(*(temp+i),inf->d_name,strlen(inf->d_name));
		i++;
	}
	sortstr(temp,num1,256);
	for(i=0;i<num1;i++)
	{
		if(readlink(*(temp+i),A,256)==-1)
		{
			printf("%s\n",*(temp+i));
			dfs(*(temp+i));
		}
	}
	for(i=0;i<num1;i++) free(*(temp+i));
	free(temp);
	closedir(dir);
}
int dls(char* fdir)
{
	DIR* dir;
	struct dirent* inf;
	char** temp;
	int num;
	int num1=0;
	char A[256];

	if((dir=opendir(fdir))==NULL) return 1;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.') continue;
		num1++;
	}
	temp=(char**)calloc(num1,sizeof(char*));
	rewinddir(dir);
	int i=0;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		*(temp+i)=(char*)calloc(num+2,sizeof(char));
		strncat(*(temp+i),fdir,strlen(fdir));
		strncat(*(temp+i),"/",2);
		strncat(*(temp+i),inf->d_name,strlen(inf->d_name));
		i++;
	}
	sortstr(temp,num1,256);
	for(i=0;i<num1;i++)
	{
		if(dls(*(temp+i))==0 || readlink(*(temp+i),A,256)!=-1 )
		{
			printf("%s\n",*(temp+i));
			dls(*(temp+i));
		}
	}
	for(i=0;i<num1;i++) free(*(temp+i));
	free(temp);
	closedir(dir);
	return 0;
}
int fls(char* fdir)
{
	DIR* dir;
	struct dirent* inf;
	char** temp;
	int num;
	int num1=0;

	if((dir=opendir(fdir))==NULL) return 1;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.') continue;
		num1++;
	}
	temp=(char**)calloc(num1,sizeof(char*));
	rewinddir(dir);
	int i=0;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		*(temp+i)=(char*)calloc(num+2,sizeof(char));
		strncat(*(temp+i),fdir,strlen(fdir));
		strncat(*(temp+i),"/",2);
		strncat(*(temp+i),inf->d_name,strlen(inf->d_name));
		i++;
	}
	sortstr(temp,num1,256);
	for(i=0;i<num1;i++)
	{
		if(dls(*(temp+i))==1)
		{
			printf("%s\n",*(temp+i));
		}
		else fls(*(temp+i));
	}
	for(i=0;i<num1;i++) free(*(temp+i));
	free(temp);
	closedir(dir);
	return 0;
}
void df(DIR* dir, char* fdir)
{
	struct dirent* inf;
	char a[256];
	char* temp;
	int num, num1;
	if((dir=opendir(fdir))==NULL) return;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		temp=(char*)calloc(num+2,sizeof(char));
		strncat(temp,fdir,strlen(fdir));
		strncat(temp,"/",2);
		strncat(temp,inf->d_name,strlen(inf->d_name));
		num1=readlink(temp,a,256);
		if(num1==-1)
			printf("%s\n",temp);
		df(dir, temp);
		free(temp);
	}
	closedir(dir);
	return;
}
int ls(char* fdir)
{
	DIR* dir;
	struct dirent* inf;
	char** temp;
	int num;
	int num1=0;
	char A[256];

	if((dir=opendir(fdir))==NULL) return 1;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.') continue;
		num1++;
	}
	temp=(char**)calloc(num1,sizeof(char*));
	rewinddir(dir);
	int i=0;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		*(temp+i)=(char*)calloc(num+2,sizeof(char));
		strncat(*(temp+i),fdir,strlen(fdir));
		strncat(*(temp+i),"/",2);
		strncat(*(temp+i),inf->d_name,strlen(inf->d_name));
		i++;
	}
	sortstr(temp,num1,256);
	for(i=0;i<num1;i++)
	{
		if(readlink(*(temp+i),A,256)!=-1 )
		{
			printf("%s\n",*(temp+i));
		}
		else ls(*(temp+i));
	}
	for(i=0;i<num1;i++) free(*(temp+i));
	free(temp);
	closedir(dir);
	return 0;
}
int dl( char* fdir)
{
	DIR* dir;
	struct dirent* inf;
	char A[256];
	char* temp;
	int num;
	if((dir=opendir(fdir))==NULL) return 1;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		temp=(char*)calloc(num+2,sizeof(char));
		strncat(temp,fdir,strlen(fdir));
		strncat(temp,"/",2);
		strncat(temp,inf->d_name,strlen(inf->d_name));
		if(dl(temp)==0 || readlink(temp,A,256)!=-1)
			printf("%s\n",temp);
		else
			dl(temp);
		free(temp);
	}
	closedir(dir);
	return 0;
}
int ds(char* fdir)
{
	DIR* dir;
	struct dirent* inf;
	char** temp;
	int num;
	int num1=0;

	if((dir=opendir(fdir))==NULL) return 1;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.') continue;
		num1++;
	}
	temp=(char**)calloc(num1,sizeof(char*));
	rewinddir(dir);
	int i=0;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		*(temp+i)=(char*)calloc(num+2,sizeof(char));
		strncat(*(temp+i),fdir,strlen(fdir));
		strncat(*(temp+i),"/",2);
		strncat(*(temp+i),inf->d_name,strlen(inf->d_name));
		i++;
	}
	sortstr(temp,num1,256);
	for(i=0;i<num1;i++)
	{
		if(ds(*(temp+i))==0)
		{
			printf("%s\n",*(temp+i));
			ds(*(temp+i));
		}
	}
	for(i=0;i<num1;i++) free(*(temp+i));
	free(temp);
	closedir(dir);
	return 0;
}
int fs(char* fdir)
{
	DIR* dir;
	struct dirent* inf;
	char** temp;
	int num;
	int num1=0;

	if((dir=opendir(fdir))==NULL) return 1;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.') continue;
		num1++;
	}
	temp=(char**)calloc(num1,sizeof(char*));
	rewinddir(dir);
	int i=0;
	while((inf=readdir(dir))!=NULL)
	{
		if(inf->d_name[0]=='.')	continue;
		num=strlen(inf->d_name)+ strlen(fdir);
		*(temp+i)=(char*)calloc(num+2,sizeof(char));
		strncat(*(temp+i),fdir,strlen(fdir));
		strncat(*(temp+i),"/",2);
		strncat(*(temp+i),inf->d_name,strlen(inf->d_name));
		i++;
	}
	sortstr(temp,num1,256);
	for(i=0;i<num1;i++)
	{
		if(fs(*(temp+i))==1)
		{
			printf("%s\n",*(temp+i));
			fs(*(temp+i));
		}
	}
	for(i=0;i<num1;i++) free(*(temp+i));
	free(temp);
	closedir(dir);
	return 0;
}